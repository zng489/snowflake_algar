import os
import sys
import base64
import snowflake.connector
 
# DATABASE (DEV OR PROD) AND QUERY
 
if len(sys.argv) < 3:
    print("Usage: python scripts/run_sf.py <DATABASE> <QUERY_FILE>")
    sys.exit(1)
 
database = sys.argv[1] 
print("Database alvo:", database)
 
 
query_path = sys.argv[2]
print("Query path:", query_path)
 
 
if not os.path.isfile(query_path):
    print(f"❌ Query file '{query_path}' not found.")
    sys.exit(1)
 
with open(query_path, 'r') as f:
    sql_query = f.read()
 
# USING PRIVATE KEY
private_key_base64 = os.environ['SNOWFLAKE_PRIVATE_KEY']
private_key_bytes = base64.b64decode(private_key_base64)
 
 
# Detalhes da sua conexão com o Snowflake
conn = snowflake.connector.connect(
    account = os.environ['SNOWFLAKE_ACCOUNT'],
    user = os.environ['SNOWFLAKE_USER'],
    private_key = private_key_bytes,
    role = os.environ['SNOWFLAKE_ROLE'], #"ACCOUNTADMIN",
    warehouse = os.environ['SNOWFLAKE_WAREHOUSE'],
    database = database
)
cs = conn.cursor()
 
 
# THEN RUN
 
try:
 
    cs.execute(f"USE DATABASE {database}")
 
    cs.execute(sql_query)
    for row in cs:
        print(row)
finally:
    cs.close()
    conn.close()
 